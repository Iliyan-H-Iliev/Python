create view view_continents_countries_currencies_details("Continent Details", "Country Information", "Currencies") as
SELECT concat(co.continent_name, ': ', co.continent_code)                        AS "Continent Details",
       concat_ws(' - '::text, c.country_name, c.capital, c.area_in_sq_km, 'km2') AS "Country Information",
       concat(cu.description, ' ', '(', cu.currency_code, ')')                   AS "Currencies"
FROM continents co,
     countries c,
     currencies cu
WHERE co.continent_code = c.continent_code
  AND c.currency_code = cu.currency_code
ORDER BY (concat_ws(' - '::text, c.country_name, c.capital, c.area_in_sq_km, 'km2')),
         (concat(cu.description, ' ', '(', cu.currency_code, ')'));

alter table view_continents_countries_currencies_details
    owner to postgres;

